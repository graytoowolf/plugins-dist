<?php

namespace XXX;

use App\Http\Controllers\Controller as BaseController;

class Controller extends BaseController
{
    //
}
