# plugin-template

This is a template repository for creating plugin, feel free to use it then modify it.

## License

MIT License
