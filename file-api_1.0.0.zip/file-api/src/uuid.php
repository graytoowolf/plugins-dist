<?php

namespace file;

use Illuminate\Database\Eloquent\Model;

class uuid extends Model
{
    protected $table = 'uuid';
}
